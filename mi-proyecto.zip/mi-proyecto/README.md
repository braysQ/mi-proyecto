# Mi proyecto: Node.js + Express + MySQL

Una lista de tareas sencilla para aprender a armar un proyecto completo y subirlo a GitHub.

| Pieza | ¿Qué hace? |
|---|---|
| Node.js | El motor que ejecuta JavaScript en tu computadora |
| Express | Organiza las rutas del servidor |
| MySQL | Guarda los datos |
| HTML + Bootstrap | La página y su diseño |
| JavaScript (`public/app.js`) | Hace que la página funcione |
| Git y GitHub | Guardan el historial de tu trabajo y una copia en la nube |

## Estructura

```
mi-proyecto/
├── public/
│   ├── index.html     ← la página
│   └── app.js         ← el código del navegador
├── server.js          ← el servidor Express
├── database.sql       ← crea la base de datos y la tabla
├── .env.example       ← modelo del archivo de contraseñas
├── .gitignore         ← lo que Git NO debe subir
└── package.json       ← la tarjeta de presentación del proyecto
```

## Antes de empezar: instala esto

1. **Node.js** (versión LTS): https://nodejs.org
   Comprueba con `node --version` y `npm --version`.
2. **Git**: https://git-scm.com/downloads
   En Mac: `xcode-select --install`. Comprueba con `git --version`.
3. **MySQL**: https://dev.mysql.com/downloads/mysql/
   Anota la contraseña que le pongas al usuario `root`.

Preséntate con Git (una sola vez):

```bash
git config --global user.name "Tu Nombre"
git config --global user.email "tu-correo@ejemplo.com"
```

## Poner a funcionar el proyecto

**1. Instala las dependencias** (dentro de la carpeta del proyecto):

```bash
npm install
```

**2. Crea la base de datos:**

```bash
mysql -u root -p < database.sql
```

Si `mysql` no se reconoce, abre MySQL Workbench, pega el contenido de `database.sql` y ejecútalo.

**3. Crea tu archivo `.env`:** copia `.env.example`, llámalo `.env` y escribe tu contraseña de MySQL.

```bash
cp .env.example .env        # Mac / Linux
copy .env.example .env      # Windows (CMD)
```

**4. Enciende el servidor:**

```bash
npm run dev
```

**5. Abre** http://localhost:3000. Arriba a la izquierda debe decir **MySQL conectado**.

## Subirlo a GitHub

**1. Guarda el proyecto con Git:**

```bash
git init
git status
git add .
git commit -m "Mi primera foto del proyecto"
```

Antes de hacer `git add .`, confirma que `.env` NO aparece en `git status`. Si aparece, algo salió mal con `.gitignore`.

**2. Crea el repositorio en GitHub:**
entra a https://github.com, pulsa **+** → **New repository**, ponle el nombre `mi-proyecto` y **no** marques "Add a README". Pulsa **Create repository**.

**3. Conecta y sube:**

```bash
git remote add origin https://github.com/TU-USUARIO/mi-proyecto.git
git branch -M main
git push -u origin main
```

**Sobre la contraseña:** GitHub ya no acepta la contraseña de tu cuenta por terminal. Si `git push` te la pide, tienes estas opciones:

- Iniciar sesión con el navegador cuando se abra la ventana (lo normal en Windows y Mac).
- Instalar GitHub CLI (https://cli.github.com) y ejecutar `gh auth login`.
- O crear un *Personal Access Token* en GitHub: Settings → Developer settings → Personal access tokens, y usarlo como contraseña.

## El ciclo de todos los días

```bash
git add .
git commit -m "describe lo que hiciste"
git push
```

## Problemas comunes

| Mensaje | Qué significa | Solución |
|---|---|---|
| `Access denied for user 'root'` | Contraseña incorrecta | Revisa `DB_PASSWORD` en `.env` |
| `Unknown database 'mi_proyecto'` | No ejecutaste `database.sql` | Repite el paso 2 |
| `ECONNREFUSED 127.0.0.1:3306` | MySQL está apagado | Enciende el servicio de MySQL |
| `EADDRINUSE :::3000` | El puerto 3000 ya está en uso | Cambia `PORT` en `.env` |
| `'nodemon' no se reconoce` | Faltó `npm install` | Ejecuta `npm install` de nuevo |
