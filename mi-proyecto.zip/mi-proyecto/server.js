require('dotenv').config();

const express = require('express');
const cors = require('cors');
const path = require('path');
const mysql = require('mysql2/promise');

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares: funciones que se ejecutan antes de tus rutas
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'))); // sirve index.html y app.js

// Conexión a MySQL (los datos vienen del archivo .env)
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'mi_proyecto',
  waitForConnections: true,
  connectionLimit: 10,
});

// Evita repetir try/catch en cada ruta
const manejar = (fn) => async (req, res) => {
  try {
    await fn(req, res);
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ error: 'No se pudo hablar con la base de datos: ' + error.message });
  }
};

// ¿Funciona todo? Sirve para probar el servidor y MySQL
app.get('/api/estado', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ servidor: 'ok', baseDeDatos: 'ok' });
  } catch (error) {
    res.json({ servidor: 'ok', baseDeDatos: 'error', detalle: error.message });
  }
});

// Leer todas las tareas
app.get('/api/tareas', manejar(async (req, res) => {
  const [filas] = await pool.query('SELECT * FROM tareas ORDER BY id DESC');
  res.json(filas);
}));

// Crear una tarea
app.post('/api/tareas', manejar(async (req, res) => {
  const titulo = (req.body.titulo || '').trim();
  if (!titulo) {
    return res.status(400).json({ error: 'Escribe un título para la tarea.' });
  }
  const [resultado] = await pool.query('INSERT INTO tareas (titulo) VALUES (?)', [titulo]);
  res.status(201).json({ id: resultado.insertId, titulo, completada: 0 });
}));

// Marcar como hecha / no hecha
app.put('/api/tareas/:id', manejar(async (req, res) => {
  const completada = req.body.completada ? 1 : 0;
  await pool.query('UPDATE tareas SET completada = ? WHERE id = ?', [completada, req.params.id]);
  res.json({ id: Number(req.params.id), completada });
}));

// Borrar una tarea
app.delete('/api/tareas/:id', manejar(async (req, res) => {
  await pool.query('DELETE FROM tareas WHERE id = ?', [req.params.id]);
  res.json({ borrada: true });
}));

app.listen(PORT, () => {
  console.log(`Servidor listo en http://localhost:${PORT}`);
});
