const formulario = document.getElementById('formulario');
const campoTitulo = document.getElementById('titulo');
const lista = document.getElementById('lista');
const vacio = document.getElementById('vacio');
const aviso = document.getElementById('aviso');
const estado = document.getElementById('estado');

// Función ayudante: llama al servidor y devuelve la respuesta en JSON
async function api(url, opciones = {}) {
  const respuesta = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...opciones,
  });
  const datos = await respuesta.json().catch(() => ({}));
  if (!respuesta.ok) {
    throw new Error(datos.error || 'Algo salió mal.');
  }
  return datos;
}

function mostrarAviso(mensaje) {
  aviso.textContent = mensaje;
  aviso.classList.remove('d-none');
}

function ocultarAviso() {
  aviso.classList.add('d-none');
}

// Revisa si el servidor y MySQL están funcionando
async function comprobarEstado() {
  try {
    const datos = await api('/api/estado');
    if (datos.baseDeDatos === 'ok') {
      estado.textContent = 'MySQL conectado';
      estado.className = 'estado ok';
    } else {
      estado.textContent = 'MySQL sin conexión';
      estado.className = 'estado error';
      mostrarAviso(
        'No se pudo conectar a MySQL. Revisa que MySQL esté encendido, que tu archivo .env ' +
        'tenga la contraseña correcta y que hayas ejecutado database.sql. Detalle: ' + datos.detalle
      );
    }
  } catch {
    estado.textContent = 'Servidor apagado';
    estado.className = 'estado error';
    mostrarAviso('No se pudo contactar al servidor. Ejecuta "npm run dev" en la terminal.');
  }
}

// Dibuja las tareas en pantalla
function dibujar(tareas) {
  lista.replaceChildren();
  vacio.classList.toggle('d-none', tareas.length > 0);

  for (const tarea of tareas) {
    const item = document.createElement('li');
    item.className = 'list-group-item tarea' + (tarea.completada ? ' hecha' : '');

    const casilla = document.createElement('input');
    casilla.type = 'checkbox';
    casilla.className = 'form-check-input mt-0';
    casilla.checked = Boolean(tarea.completada);
    casilla.setAttribute('aria-label', 'Marcar como hecha: ' + tarea.titulo);
    casilla.addEventListener('change', () => cambiarEstado(tarea.id, casilla.checked));

    const texto = document.createElement('span');
    texto.className = 'texto';
    texto.textContent = tarea.titulo; // textContent evita que se cuele código malicioso

    const borrar = document.createElement('button');
    borrar.className = 'btn btn-sm btn-outline-danger';
    borrar.textContent = 'Borrar';
    borrar.addEventListener('click', () => borrarTarea(tarea.id));

    item.append(casilla, texto, borrar);
    lista.append(item);
  }
}

async function cargarTareas() {
  try {
    const tareas = await api('/api/tareas');
    ocultarAviso();
    dibujar(tareas);
  } catch (error) {
    mostrarAviso(error.message);
  }
}

async function cambiarEstado(id, completada) {
  try {
    await api('/api/tareas/' + id, { method: 'PUT', body: JSON.stringify({ completada }) });
    await cargarTareas();
  } catch (error) {
    mostrarAviso(error.message);
  }
}

async function borrarTarea(id) {
  try {
    await api('/api/tareas/' + id, { method: 'DELETE' });
    await cargarTareas();
  } catch (error) {
    mostrarAviso(error.message);
  }
}

formulario.addEventListener('submit', async (evento) => {
  evento.preventDefault(); // evita que la página se recargue
  const titulo = campoTitulo.value.trim();
  if (!titulo) return;

  try {
    await api('/api/tareas', { method: 'POST', body: JSON.stringify({ titulo }) });
    campoTitulo.value = '';
    await cargarTareas();
  } catch (error) {
    mostrarAviso(error.message);
  }
});

comprobarEstado();
cargarTareas();
