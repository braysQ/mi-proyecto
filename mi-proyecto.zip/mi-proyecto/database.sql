-- Ejecuta este archivo UNA vez para crear la base de datos y la tabla.
-- Desde la terminal:   mysql -u root -p < database.sql

CREATE DATABASE IF NOT EXISTS mi_proyecto
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE mi_proyecto;

CREATE TABLE IF NOT EXISTS tareas (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  titulo     VARCHAR(200) NOT NULL,
  completada TINYINT(1)   NOT NULL DEFAULT 0,
  creada_en  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
);
